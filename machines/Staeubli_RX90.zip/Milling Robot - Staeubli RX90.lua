-- This is the description file for an industrial robot.
-- The robot is holding the milling head with the tool.
-- The whole assembly operates as a 5 axis CNC machine.

-- Definition of the geometry

-- Base of the machine
setstyle(0.9,0.5,0.1);
loadgeometry("rx90_base.stl");

-- Box next to the base with the workpiece on top.
setstyle(0.5,0.5,0.5);
translate(0.7,-0.3,0.2);
box(0.2,0.2,0.4);

translate(-0.1,-0.1,0.2);
tableorigin(); -- sets the origin of the workpiece.
-- The tableorigin is the position, where the part to be milled is placed.
-- This command has to be in every machine description exactly once.

addcomponent("Link1");
setstyle(0.9,0.5,0.1);
loadgeometry("rx90_joint1.stl");

addcomponent("Link2");
setstyle(0.9,0.5,0.1);
loadgeometry("rx90_joint2.stl");

addcomponent("Link3");
setstyle(0.9,0.5,0.1);
loadgeometry("rx90_joint3.stl");

addcomponent("Link4");
setstyle(0.9,0.5,0.1);
loadgeometry("rx90_joint4.stl");

addcomponent("Link5");
setstyle(0.6,0.6,0.6);
loadgeometry("rx90_joint5.stl");

addcomponent("Head");
setstyle(0.6,0.3,0.1);
translate(0,0,1.644);
rotate(90,0,90);
loadgeometry("millinghead.stl");

translate(0,0.04,0.12813);
rotate(180,0,90);
toolholder(); -- This is the place where the milling tool is placed.
-- This command has to be in every machine description exactly once.


-- The next function is called for assembling
-- the parts of the machine. 
function AssembleMachine()

	-- The joints of the robot are moved out of the straight configuration
        -- To prevent gimbal locking in the IK solver.
	joint1 = AXIS_1;
	joint2 = AXIS_2-20;
	joint3 = AXIS_3+100;
	joint4 = AXIS_4;
	joint5 = AXIS_5+10;
  	joint6 = AXIS_6;
     
	identity();
	rotate(0,0,joint1);
	placecomponent("Link1");
	rotate(0,joint2,0,-0.002,-0.201,0.43);
	placecomponent("Link2");
	rotate(0,joint3,0,-0.002,-0.201,0.886);
	placecomponent("Link3");
	rotate(0,0,joint4,-0.005,0.0,0.988);
	placecomponent("Link4");
	rotate(0,joint5,0,-0.002,0.0,1.562);
	placecomponent("Link5");
	rotate(0,0,joint6,0.0,0.0,0.0);
	placecomponent("Head");

end

