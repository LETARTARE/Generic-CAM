-- This is the description file for a swivelhead mill.
-- This type of machine is a 4-axis machine where
-- the head of the CNC machine can rotate around
-- the y axis.

-- Definition of the geometry
-- Base of the machine
setstyle(0.9,0.5,0.1);
loadgeometry("base.stl");

addcomponent("Bench");
setstyle(0.5,0.5,0.6);
loadgeometry("bench.stl");

translate(0.0,-0.2,0.6);
translate(0,-0.1,0);
tableorigin(); -- sets the origin of the workpiece.
-- The tableorigin is the position, where the part to be milled is placed.
-- This command has to be in every machine description exactly once.

addcomponent("Column");
setstyle(0.9,0.5,0.1);
loadgeometry("column.stl");

addcomponent("Link");
setstyle(0.9,0.5,0.1);
loadgeometry("connector.stl");

addcomponent("Head");
setstyle(0.9,0.5,0.1);
loadgeometry("head.stl");

translate(0,-0.2,0.647);
toolholder(); -- This is the place where the milling tool is placed.
-- This command has to be in every machine description exactly once.

-- The next function is called for assembling
-- the parts of the machine. 
function AssembleMachine()
	identity();
	translate(-AXIS_X,-0.05-AXIS_Y,0);
	placecomponent("Bench");
	identity();
  translate(0,0,AXIS_Z+0.3);
	placecomponent("Column");
	rotate(0,AXIS_B,0,0,-0.2,1.2);
	placecomponent("Link");
  translate(0,0,AXIS_W);
	placecomponent("Head");
end

