-- Definition file for a High-Z 720 machine (CNC-Step)

-- Definition of the geometry

-- Base of the machine
identity();
setstyle(0.62745100,0.62745100,0.64313728);
translate(0,0.2855,0);
rotate(0,0,-90);
loadgeometry("base.stl");

identity();
translate(0.065,-0.20,0.06);
tableorigin(); -- sets the origin of the table.
-- This command has to be in every machine description exactly once.
-- The tableorigin is the position, where the part to be milled is placed.

addcomponent("bridge1");
setstyle(0.00000000,0.50196081,0.50196081);
translate(0,0.2855,0);
rotate(0,0,-90);
loadgeometry("bridge.stl");

addcomponent("bridge2");
setstyle(0.75294119,0.86274511,0.75294119);
translate(0,0.2855,0);
rotate(0,0,-90);
loadgeometry("bridge2.stl");

addcomponent("tool");
setstyle(0.65098041,0.79215688,0.94117647);
translate(0,0.2855,0);
rotate(0,0,-90);
loadgeometry("tool.stl");
translate(0.18,0.07,0.17);
loadgeometry("spindel.stl");

identity();
translate(0.07,0.1055,0.116);
rotate(0,0,0);
toolholder(); -- This is the place where the milling tool is placed.
-- This command has to be in every machine description exactly once.


-- The next function is called for assembling the parts of the machine. 
function AssembleMachine()
  -- all axes are shifte a little to set the origin of the machine 
  -- coordinate system for AXIS_1..3 = 0
	identity();
	translate(AXIS_1-0.04,0,0);
	placecomponent("bridge1");
	translate(0,AXIS_2-0.31,0);
	placecomponent("bridge2");
	translate(0,0,AXIS_3+0.08);
	placecomponent("tool");
end

