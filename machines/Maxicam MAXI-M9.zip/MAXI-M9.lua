-- Definition file for a 5 axis portal CNC machine

-- Definition of the geometry

-- Base of the machine
identity();
setstyle(0.62745100,0.62745100,0.64313728);
loadgeometry("base.stl");
translate(0,0,0.0)
tableorigin(); -- sets the origin of the table.
-- This command has to be in every machine description exactly once.
-- The tableorigin is the position, where the part to be milled is placed.

addcomponent("bridge");
setstyle(0.00000000,0.50196081,0.50196081);
loadgeometry("bridge.stl");

addcomponent("bridge2");
setstyle(0.75294119,0.86274511,0.75294119);
loadgeometry("bridge2.stl");

addcomponent("beam");
setstyle(0.75294119,0.86274511,0.75294119);
loadgeometry("beam.stl");

addcomponent("head");
setstyle(0.65098041,0.79215688,0.94117647);
loadgeometry("head.stl");

addcomponent("head2");
setstyle(0.65098041,0.79215688,0.94117647);
loadgeometry("head2.stl");

-- identity();
translate(-2.0703,0,2.1);
-- rotate(0,0,0);
toolholder(); -- This is the place where the milling tool is placed.
-- This command has to be in every machine description exactly once.


-- The next function is called for assembling
-- the parts of the machine. 
function AssembleMachine()

	cb = math.cos(AXIS_5/180*math.pi);
	sb = math.sin(AXIS_5/180*math.pi);
	cc = math.cos(AXIS_6/180*math.pi);
	sc = math.sin(AXIS_6/180*math.pi);

	L = 2.5964 - 1.809;
	X =  AXIS_1+sb*L;
	Z = AXIS_3+cb*L;
	X2 = X + (cc-1) * sb*L;
	Y2 = AXIS_2 + sc*sb*L;

	identity();
	translate(X2,0,0);
	placecomponent("bridge");
	translate(0,Y2,0);
	placecomponent("bridge2");
	translate(0,0,Z);
	placecomponent("beam");
	rotate(0,0,AXIS_6,-2.0703,0,3.4566);
	placecomponent("head");
	rotate(0,AXIS_5,0,-2.0703,0,2.5964);
	placecomponent("head2");

end

