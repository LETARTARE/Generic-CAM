-- This is the description file for a 5-axis CNC machine.
-- The machine is a swivel table machine. The head with
-- the tool moves in XYZ direction. The table rotates
-- around the two axis A and C.

-- Definition of the geometry

-- Base of the machine
identity();
setstyle(0.3,0.3,0.3);
loadgeometry("base.stl");

addcomponent("Swing");
setstyle(0.9,0.3,0.1);
loadgeometry("swing.stl");

addcomponent("Table");
setstyle(0.9,0.5,0.1);
loadgeometry("table.stl");

identity();
translate(0.0,-0.6,0.483);
translate(-0.15,-0.15,0);
tableorigin(); -- sets the origin of the workpiece.
-- The tableorigin is the position, where the part to be milled is placed.
-- This command has to be in every machine description exactly once.

addcomponent("Telescope 1");
setstyle(0.8,0.3,0.1);
loadgeometry("telescope1.stl");

addcomponent("Telescope 2");
setstyle(0.9,0.3,0.1);
loadgeometry("telescope2.stl");

addcomponent("Telescope 3");
setstyle(0.9,0.3,0.1);
loadgeometry("telescope3.stl");

addcomponent("Head");
setstyle(0.9,0.5,0.1);
loadgeometry("head.stl");

translate(0,-0.6,0.8806);
toolholder(); -- This is the place where the milling tool is placed.
-- This command has to be in every machine description exactly once.


-- The next function is called for assembling
-- the parts of the machine. 
function AssembleMachine()

	identity();
	rotate(-AXIS_A,0,0,0,-0.6,0.48);
	placecomponent("Swing");
	rotate(0,0,-AXIS_C,0.0,-0.6,0.447);
	placecomponent("Table");

	-- The following transformation will not be necessary in the future.
	-- The IK that positions the robot will also solve the kinematics,
	-- written down below.
	C = math.cos(AXIS_C/180*math.pi);
  S = math.sin(AXIS_C/180*math.pi);

  X = AXIS_X*C + (AXIS_Y+0.4)*S;
  Y = (AXIS_Y+0.4)*C - AXIS_X*S;
  Z = AXIS_Z+0.3;

  C = math.cos(AXIS_A/180*math.pi);
  S = math.sin(AXIS_A/180*math.pi);

  H = Y;
  Y = Y*C +Z*S;
  Z = Z*C - H*S;

  X = X + AXIS_U;
  Y = Y + AXIS_V;
  Z = Z + AXIS_W;

  Z = Z - 0.3976;

	identity();
	translate(X,0,0);
  placecomponent("Telescope 1");
	translate(0,0,Z/2);
	placecomponent("Telescope 2");
	translate(0,0,Z/2);
	placecomponent("Telescope 3");
	translate(0,Y,0);
	placecomponent("Head");
end

