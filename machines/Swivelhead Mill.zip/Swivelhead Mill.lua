-- This is the description file for a swivelhead mill.
-- This type of machine is a 4-axis machine where
-- the head of the CNC machine can rotate around
-- the y axis.

-- Definition of the geometry
-- Base of the machine
setstyle(0.9,0.5,0.1);
loadgeometry("base.stl");

addcomponent("Bench");
setstyle(0.5,0.5,0.6);
loadgeometry("bench.stl");

translate(0.0,-0.2,0.6);
translate(0,-0.1,0);
tableorigin(); -- sets the origin of the workpiece.
-- The tableorigin is the position, where the part to be milled is placed.
-- This command has to be in every machine description exactly once.

addcomponent("Column");
setstyle(0.9,0.5,0.1);
loadgeometry("column.stl");

addcomponent("Link");
setstyle(0.9,0.5,0.1);
loadgeometry("connector.stl");

addcomponent("Head");
setstyle(0.9,0.5,0.1);
loadgeometry("head.stl");

translate(0,-0.2,0.647);
toolholder(); -- This is the place where the milling tool is placed.
-- This command has to be in every machine description exactly once.

-- The next function is called for assembling
-- the parts of the machine. 
function AssembleMachine()

	C = math.cos(AXIS_5/180*math.pi);
	S = math.sin(AXIS_5/180*math.pi);

	X = -AXIS_1- 0.5530*S;
	Z = AXIS_3+0.5530*C - 0.3;
	Y = -AXIS_2-0.05;

	identity();
	translate(X,Y,0);
	placecomponent("Bench");
	identity();
	translate(0,0,Z);
	placecomponent("Column");
	rotate(0,AXIS_5,0,0,-0.2,1.2);
	placecomponent("Link");
	translate(0,0,AXIS_7);
	placecomponent("Head");
end

