
-- Base of the machine
setstyle(0.9,0.5,0.1);
loadgeometry("Staeubli TS2-60_Base.stl");

-- Box next to the base with the workpiece on top.
setstyle(0.5,0.5,0.5);
translate(0.30,-0.30,0.05);
box(0.2,0.2,0.1);

translate(-0.00,-0.00,0.05);
tableorigin(); -- sets the origin of the workpiece.
-- The tableorigin is the position, where the part to be milled is placed.
-- This command has to be in every machine description exactly once.

addcomponent("Arm1");
setstyle(0.9,0.5,0.1);
loadgeometry("Staeubli TS2-60_Arm1.stl");

addcomponent("Arm2");
setstyle(0.9,0.5,0.1);
loadgeometry("Staeubli TS2-60_Arm2.stl");

addcomponent("Head");
setstyle(0.8,0.8,0.5);
loadgeometry("Staeubli TS2-60_Head.stl");

translate(0.71,0.0,0.09831);
toolholder(); -- This is the place where the milling tool is placed.
-- This command has to be in every machine description exactly once.


-- The next function is called for assembling
-- the parts of the machine. 
function AssembleMachine()

	-- The joints of the robot are moved out of the straight configuration
        -- To prevent gimbal locking in the IK solver.
	joint1 = AXIS_1-15;
	joint2 = AXIS_2-110;
	joint3 = AXIS_3+0.25;	
     
	identity();
	rotate(0, 0, joint1);
	placecomponent("Arm1");
	rotate(0, 0, joint2,0.43206,0,0.501);
	placecomponent("Arm2");
	rotate(0, 0, -joint1-joint2, 0.71, 0, 0.062271);
	translate(0, 0, joint3);
	placecomponent("Head");

end

