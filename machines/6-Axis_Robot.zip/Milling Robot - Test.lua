-- This is the description file for a crude robot whipped 
-- together quickly in Blender.
-- Tests the kinematics, where the tool is stationary and
-- the workpiece is moved around the stationary tool by the robot.
--
-- http://www.robotmatrix.org/RobotConfiguration.htm


-- Definition of the geometry

-- Base of the machine
setstyle(0,0.5,0)
loadgeometry("robot1.stl");

identity();

translate(3,0,0.5);
setstyle(0.4,0.4,0.4)
cylinder(0.6,0.2);

translate(0,0,0.3);
setstyle(0.8,0.5,0.1)
cylinder(0.3,0.01,0.05);

translate(0,0,0.15);
rotate(180,0,0);
toolholder(); -- This is the place where the milling tool is placed.
-- This command has to be in every machine description exactly once.

addcomponent("Link1");
setstyle(0,0.7,0)
loadgeometry("robot2.stl");

addcomponent("Link2");
setstyle(0,0.7,0)
loadgeometry("robot3.stl");

addcomponent("Link3");
setstyle(0,0.7,0)
loadgeometry("robot4.stl");

addcomponent("Link4");
setstyle(0,0.7,0)
loadgeometry("robot5.stl");

addcomponent("Link5");
setstyle(0,0.7,0)
loadgeometry("robot6.stl");

addcomponent("Link6");
setstyle(0,0.3,0)
loadgeometry("robot7.stl");

translate(5.149,0,1.6);
rotate(0,90,0);
translate(-0.2,-0.15,0.0);
tableorigin(); -- sets the origin of the workpiece.
-- The tableorigin is the position, where the part to be milled is placed.
-- This command has to be in every machine description exactly once.


-- The next function is called for assembling
-- the parts of the machine. 
function AssembleMachine()
	  
	joint1 = AXIS_1*180+0;
	joint2 = AXIS_2*180-55;
	joint3 = AXIS_3*180+115;
	joint4 = AXIS_4;
	joint5 = AXIS_5+30;
	joint6 = AXIS_6;
     
	identity();
	rotate(0,0,joint1);
	placecomponent("Link1");
	rotate(0,joint2,0,0.6,0.0,1.6);
	placecomponent("Link2");
	rotate(0,joint3,0,2.952,0.0,1.6);
	placecomponent("Link3");
	rotate(joint4,0,0,4.134,0.0,1.6);
	placecomponent("Link4");
	rotate(0,joint5,0,4.586,0.0,1.6);
	placecomponent("Link5");
	rotate(joint6,0,0,5.083,0.0,1.6);
	placecomponent("Link6");
	
end

